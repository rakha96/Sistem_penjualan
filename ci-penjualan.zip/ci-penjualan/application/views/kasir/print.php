<html>
<head>
    <title>Faktur Pembayaran</title>
    <style>
        #tabel
        {
        font-size:15px;
        border-collapse:collapse;
        }
        #tabel  td
        {
        /* padding-left:2px; */
        border: 1px solid black;
        }
    </style>
</head>
<body style='font-family:tahoma; font-size:8pt;'>
    <center>
        <table style='width:350px; font-size:16pt; font-family:calibri; border-collapse: collapse;' border = '0'>
            <td width='70%' align='CENTER' vertical-align:top'><span style='color:black;'>
                <b><?= $toko->nama_toko ?></b></span><br>
                <span  style='font-size:12pt'><?= $toko->alamat ?></span><br>
                <span style='font-size:12pt'>No. : <?= $penjualan->no_penjualan ?>,  (user:<?= $penjualan->nama_kasir ?>)<br> <?= $penjualan->tgl_penjualan ?> <?= $penjualan->jam_penjualan ?></span><br>
            </td>
        </table>
<style>
hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    /* margin-left: auto;
    margin-right: auto; */
    border-style: inset;
    border-width: 1px;
} 
</style>
    <table cellspacing='0' cellpadding='0' style='width:350px; font-size:12pt; font-family:calibri;  border-collapse: collapse;' border='0'>
        <tr >
            <td align='left' width='10%'>Item</td>
            <td width='10%'>Price</td>
            <td width='7%'>Qty</td>
            <td width='7%'>Diskon %</td>
            <td align='center' width='10%'>Total</td><tr>
            <td colspan='5'><hr></td></tr>
        </tr>
        <?php foreach ($all_detail_penjualan as $detail_penjualan): ?>
            <tr>
                <td style='vertical-align:top'><?= $detail_penjualan->nama_barang ?></td>
                <td style='vertical-align:top; text-align:right; padding-right:10px'><?= number_format($detail_penjualan->harga_barang, 0, ',', '.') ?></td>
                <td style='vertical-align:top; text-align:right; padding-right:10px'><?= $detail_penjualan->jumlah_barang ?> <?= strtoupper($detail_penjualan->satuan) ?></td>
                <td style='vertical-align:top; text-align:right; padding-right:10px'>0,00%</td>
                <td style='text-align:center; vertical-align:top'><?= number_format($detail_penjualan->sub_total, 0, ',', '.') ?></td>
            </tr>
            
        <?php endforeach ?>
            <tr>
            <td colspan='5'><hr></td>
            </tr>
            <!-- <tr>
                <td colspan = '4'>
                <div style='text-align:right'>Biaya Adm : </div>
                </td>
                <td style='text-align:right; font-size:14pt;'>Rp3.500,00</td>
            </tr> -->
            <tr>
                <td colspan = '3'>
                    <div style='text-align:right; color:black'>Total : </div>
                </td>
                <td colspan = '2' style='text-align:center; font-size:14pt; color:black'>Rp <?= number_format($penjualan->total, 0, ',', '.') ?>
                </td>
            </tr>
            <!-- <tr> -->
            <!-- <td colspan = '4'><div style='text-align:right'>Biaya Adm : </div></td><td style='text-align:right; font-size:16pt;'>Rp3.500,00</td>
            </tr> -->
            
            <!-- <tr> -->
                <!-- <td colspan = '4'><div style='text-align:right; color:black'>Cash : </div></td><td style='text-align:right; font-size:16pt; color:black'>1.000.000</td>
                </tr>
                <tr>
                <td colspan = '4'><div style='text-align:right; color:black'>Change : </div></td><td style='text-align:right; font-size:16pt; color:black'>252.500</td>
                </tr>
                <tr>
                <td colspan = '4'><div style='text-align:right; color:black'>DP : </div></td><td style='text-align:right; font-size:16pt; color:black'>0</td>
                </tr> -->
            <!-- <tr> -->
                <!-- <td colspan = '4'><div style='text-align:right; color:black'>Sisa : </div></td><td style='text-align:right; font-size:16pt; color:black'>0</td> -->
            <!-- </tr> -->
    </table>
    <br>
    <table style='width:350; font-size:12pt;' cellspacing='2'>
        <tr>
        <td width='10%'></td>
        <td align='left'>****** TERIMAKASIH ******</br>
        </td>
        </tr>
    </table>
</center>
</body>
</html>