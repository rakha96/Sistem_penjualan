<?php

use Dompdf\Dompdf;


class Konfigurasi extends CI_Controller{
	public function __construct(){
		parent::__construct();
		if($this->session->login['role'] != 'kasir' && $this->session->login['role'] != 'admin') redirect();
		$this->data['aktif'] = 'konfig';
		$this->load->model('M_kasir', 'm_kasir');
		$this->load->model('M_penjualan', 'm_penjualan');
		$this->load->model('M_detail_penjualan', 'm_detail_penjualan');
		$this->load->model('M_toko', 'm_toko');
	}

	public function index(){
		$this->data['title'] = 'Konfigurasi';
		$this->data['all_kasir'] = $this->m_kasir->lihat();
		$this->data['toko']     = $this->m_toko->lihat();
        // var_dump($this->data);die;
		$this->data['no'] = 1;

		$this->load->view('konfigurasi/konfig', $this->data);
	}

	public function tambah(){
		if ($this->session->login['role'] == 'kasir'){
			$this->session->set_flashdata('error', 'Tambah data hanya untuk admin!');
			redirect('penjualan');
		}

		$this->data['title'] = 'Tambah Kasir';

		$this->load->view('kasir/tambah', $this->data);
	}

	public function proses_tambah(){
		if ($this->session->login['role'] == 'kasir'){
			$this->session->set_flashdata('error', 'Tambah data hanya untuk admin!');
			redirect('penjualan');
		}

		$data = [
			'kode_kasir' => $this->input->post('kode_kasir'),
			'nama_kasir' => $this->input->post('nama_kasir'),
			'username_kasir' => $this->input->post('username_kasir'),
			'password_kasir' => $this->input->post('password_kasir'),
		];

		if($this->m_kasir->tambah($data)){
			$this->session->set_flashdata('success', 'Data Kasir <strong>Berhasil</strong> Ditambahkan!');
			redirect('kasir');
		} else {
			$this->session->set_flashdata('error', 'Data Kasir <strong>Gagal</strong> Ditambahkan!');
			redirect('kasir');
		}
	}

	public function ubah($id){
		if ($this->session->login['role'] == 'kasir'){
			$this->session->set_flashdata('error', 'Ubah data hanya untuk admin!');
			redirect('penjualan');
		}

		$this->data['title'] = 'Ubah Kasir';
		$this->data['kasir'] = $this->m_kasir->lihat_id($id);

		$this->load->view('kasir/ubah', $this->data);
	}

	public function proses_ubah(){
		if ($this->session->login['role'] == 'kasir'){
			$this->session->set_flashdata('error', 'Ubah data hanya untuk admin!');
			redirect('konfigurasi');
		}

		$data = [
			'printer' => $this->input->post('settingprinter')
		];


		if($this->m_toko->ubah($data)){
			$this->session->set_flashdata('success', 'Perubahan setting <strong>Berhasil</strong> Diubah!');
			redirect('konfigurasi');
		} else {
			$this->session->set_flashdata('error', 'Perubahan setting<strong>Gagal</strong> Diubah!');
			redirect('konfigurasi');
		}
	}


}