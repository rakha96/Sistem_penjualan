<?php
require __DIR__ . '/../vendor/.composer/autoload.php';
?>